SMILERS - README 

- Smilers is currently of version 1.0 (the first version ever released)

- Smilers is freeware - you may copy it as much as you want, but you
  aren't allowed to modify it in any form.

- released 1.July 1999

KEYS

Green Player: A,W,S,D, TAB

Yellow Player: ARROWS, SPACEBAR

--- See the help file for additional gameplay info.

INSTALLING

To install, just unzip everything to a subfolder,
maybe add some shortcuts to it and run it. 
Smilers makes no registery changes to Windows, 
so unistalling is just as easy, delete the subfolder 
to get rid of Smilers

LEVEL EDITOR

Level editor is provided as is. There is no help
currently available to it, but it should be to learn
to use it. Teleports and switches are placed by
first placing the item and then clicking the square
you want it to affect. That's all.

KNOWN BUGS

There are number of minor bugs in Smilers, because
at the time this was released, I had to go to the
army and I hadn't time to fix all of them.

1. Smilers keeps receiving movement commands although
it is not the active window, for example when you
have to write some message with notepad while playing,
the players still move if you press the movement
keys. Not really a bug, but can be annoying. I know
how to fix it, but I didn't have the time. Hey,
you can play two games at a time like this! I might
start calling it a feature!

2. There are some bugs in the gameplay core, like
if you run past a dynamite thats one square above
you and the surroundings are filled with dirt, 
if you run from the other direction you die and 
if from the other, you survive. I have tried to
avoid situations like this in the levels. 

LEGAL STUFF

If the files included in the Smilers package do something they
shouldn't do to your computer, I don't care and I cannot
be held responsible. Use at your own risk!

--- Copyright 1999 Kimmo Lahtinen, All Rights Reserved.
